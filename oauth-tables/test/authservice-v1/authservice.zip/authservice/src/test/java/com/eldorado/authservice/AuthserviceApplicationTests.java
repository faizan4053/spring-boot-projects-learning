package com.eldorado.authservice;

import static org.junit.Assert.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AuthserviceApplicationTests {

	@Test
	void contextLoads() {
		assertTrue(true);
	}

}
